/** Automatically generated file. DO NOT MODIFY */
package com.example.ui.simpleuifinal;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}