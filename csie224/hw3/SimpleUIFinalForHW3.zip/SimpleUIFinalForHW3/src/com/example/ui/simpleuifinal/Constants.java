package com.example.ui.simpleuifinal;

public class Constants {
	public static final String TABLE_NAME = "MessageForHW3";

}
